package com.meme.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var mic: Button
    private lateinit var endpoint: EditText
    private lateinit var model: EditText
    private lateinit var apiKey: EditText
    private lateinit var onlineSwitch: Switch
    private lateinit var tts: TextToSpeech
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("meme_memory", MODE_PRIVATE) }
    private var speech: SpeechRecognizer? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition service is not available on this phone."
            mic.isEnabled = false
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF101827.toInt())
        }
        fun label(text: String, size: Float = 16f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFFF4F7FF.toInt())
                setPadding(0, 8, 0, 8)
            }
        root.addView(label("M.E.M.E.", 32f))
        root.addView(label("Your personal Hindi + English assistant", 15f))
        status = label("Ready. Tap the microphone to speak.")
        root.addView(status)
        mic = Button(this).apply {
            text = "🎙  TAP TO TALK"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        root.addView(mic, LinearLayout.LayoutParams(-1, -2))
        conversation = label("MEME: Namaste! Main MEME hoon. How can I help?")
        conversation.textSize = 17f
        root.addView(conversation)
        val scroll = ScrollView(this)
        scroll.addView(LinearLayout(this).apply { addView(label(" ")) })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(label("Optional online AI (only if you have a provider's free API access)", 14f))
        onlineSwitch = Switch(this).apply {
            text = "Enable online AI"
            setTextColor(0xFFF4F7FF.toInt())
            isChecked = false
        }
        root.addView(onlineSwitch)
        endpoint = EditText(this).apply {
            hint = "Chat-completions endpoint URL"
            setSingleLine()
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
        }
        model = EditText(this).apply {
            hint = "Model name"
            setSingleLine()
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
        }
        apiKey = EditText(this).apply {
            hint = "API key (stored only on this phone)"
            setSingleLine()
            inputType = 0x00000081
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
        }
        root.addView(endpoint)
        root.addView(model)
        root.addView(apiKey)
        val save = Button(this).apply {
            text = "Save online AI settings"
            setOnClickListener {
                val url = endpoint.text.toString().trim()
                if (onlineSwitch.isChecked && !url.startsWith("https://")) {
                    status.text = "Use a secure HTTPS endpoint."
                } else {
                    prefs.edit()
                        .putString("endpoint", url)
                        .putString("model", model.text.toString().trim())
                        .putString("key", apiKey.text.toString())
                        .putBoolean("online", onlineSwitch.isChecked)
                        .apply()
                    status.text = "Settings saved on this phone."
                }
            }
        }
        root.addView(save)
        setContentView(root)

        endpoint.setText(prefs.getString("endpoint", ""))
        model.setText(prefs.getString("model", ""))
        apiKey.setText(prefs.getString("key", ""))
        onlineSwitch.isChecked = prefs.getBoolean("online", false)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "No speech recognition service found."
            return
        }
        mic.isEnabled = false
        status.text = "Listening…"
        speech?.destroy()
        speech = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… बोलिए" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Thinking…" }
                override fun onError(error: Int) {
                    status.text = "Didn't catch that. Tap and try again."
                    mic.isEnabled = true
                    recognizer.destroy()
                }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    mic.isEnabled = true
                    recognizer.destroy()
                    handleUserText(words)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            recognizer.startListening(intent)
        }
    }

    private fun handleUserText(text: String) {
        if (text.isBlank()) {
            status.text = "No speech detected. Tap to try again."
            return
        }
        conversation.text = "You: $text\n\nMEME: सोच रही हूँ…"
        val local = localAnswer(text)
        if (local != null) {
            showAnswer(local)
        } else if (prefs.getBoolean("online", false)) {
            askOnline(text)
        } else {
            showAnswer("मैं अभी basic offline mode में हूँ. Online AI के लिए Settings में अपना secure provider endpoint और API details जोड़ें.")
        }
    }

    private fun localAnswer(raw: String): String? {
        val q = raw.lowercase(Locale.ROOT)
        return when {
            listOf("hello", "hi", "नमस्ते", "नमस्कार", "hey").any { q.contains(it) } ->
                "Hello! Main MEME hoon. बताइए, मैं आपकी क्या मदद करूँ?"
            q.contains("time") || q.contains("समय") || q.contains("टाइम") ->
                "अभी समय है " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            q.contains("date") || q.contains("तारीख") || q.contains("आज कौन सा दिन") ->
                "आज " + SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("hi", "IN")).format(Date())
            q.contains("your name") || q.contains("तुम्हारा नाम") || q.contains("नाम क्या") ->
                "मेरा नाम MEME है — आपकी personal AI assistant."
            q.startsWith("remember ") || q.startsWith("याद रखना ") ->
                val note = raw.substringAfter(" ", "")
                if (note.isNotBlank()) {
                    val old = prefs.getString("notes", "").orEmpty()
                    prefs.edit().putString("notes", (old + "\n" + note).trim()).apply()
                    "ठीक है, मैंने यह बात इस फोन में सेव कर ली."
                } else "क्या याद रखना है?"
            q.contains("what do you remember") || q.contains("याद है") || q.contains("मेरी बातें") ->
                "आपकी सेव की हुई बातें:\n" + (prefs.getString("notes", "").orEmpty().ifBlank { "अभी कोई नोट सेव नहीं है." })
            q.contains("help") || q.contains("मदद") ->
                "आप मुझसे समय, तारीख पूछ सकते हैं या 'remember' बोलकर कोई नोट सेव कर सकते हैं."
            else -> null
        }
    }

    private fun askOnline(userText: String) {
        val urlText = prefs.getString("endpoint", "").orEmpty()
        val modelName = prefs.getString("model", "").orEmpty()
        val key = prefs.getString("key", "").orEmpty()
        if (!urlText.startsWith("https://") || modelName.isBlank() || key.isBlank()) {
            showAnswer("Online AI सेटअप अधूरा है. कृपया HTTPS endpoint, model और API key सेट करें. आप बिना API key के offline commands इस्तेमाल कर सकते हैं.")
            return
        }
        worker.execute {
            try {
                val conn = (URL(urlText).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }
                val body = JSONObject()
                    .put("model", modelName)
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content",
                            "You are MEME, a concise, friendly female-voiced Hindi-English personal assistant. Reply in the user's language. Do not claim to perform phone actions."))
                        .put(JSONObject().put("role", "user").put("content", userText)))
                    .put("temperature", 0.5)
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val answer = if (code in 200..299) {
                    JSONObject(response).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content")
                } else "Online AI error ($code). Check your provider settings."
                runOnUiThread { showAnswer(answer) }
            } catch (e: Exception) {
                runOnUiThread { showAnswer("Online AI connect नहीं हो पाया. Internet और provider settings check करें.") }
            }
        }
    }

    private fun showAnswer(answer: String) {
        conversation.text = conversation.text.substringBefore("\n\nMEME:") + "\n\nMEME: " + answer
        status.text = "Ready. Tap the microphone to speak again."
        if (ttsReady) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "meme_reply")
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val hindi = tts.setLanguage(Locale("hi", "IN"))
            if (hindi == TextToSpeech.LANG_MISSING_DATA || hindi == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US)
            }
            // Prefer a voice whose installed voice name is labelled female, if the engine exposes one.
            val voices = tts.voices.orEmpty()
            val female = voices.firstOrNull {
                it.name.contains("female", ignoreCase = true) &&
                    (it.locale.language == "hi" || it.locale.language == "en")
            }
            if (female != null) tts.voice = female
            tts.setSpeechRate(1.05f)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startListening()
            } else {
                status.text = "Microphone permission denied. You can still read the app screen."
            }
        }
    }

    override fun onDestroy() {
        speech?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }
}
